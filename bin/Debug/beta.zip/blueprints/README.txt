A blueprint inherits all data fields from Inherits "Title"
Those section can be overwritten in a child BUT ONLY IF THE WHOLE FIELD IS DECLARED
So if you want to overwrite the collision for Default thruster, you need to define the whole Collision field.